version="0.6.0"
tags={
	"National Focuses"
	"Gameplay"
	"Balance"
}
name="기본 중점 개편"
supported_version="1.19.3.*"
