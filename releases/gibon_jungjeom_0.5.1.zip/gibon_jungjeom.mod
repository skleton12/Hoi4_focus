version="0.5.1"
tags={
	"National Focuses"
	"Gameplay"
	"Balance"
}
name="기본 중점 개편"
supported_version="1.19.3.*"
path="mod/gibon_jungjeom"
